%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
File: AllanVarianceDriver.m

Desc: Driver code to call code provided to us in the lab manual:
https://www.mathworks.com/help/nav/ug/inertial-sensor-noise-analysis-using-allan-variance.html

Create 6 Allan variance plots (3 for gyro, 3 for accelerometer), and show
some noise / error statistics for each
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc; clear; close all;

% Read data from CSV file (assuming the file contains columns for time,
% accelerometer X, accelerometer Y, accelerometer Z, gyro X, gyro Y, gyro Z)
data = readmatrix('five_hrs-imu.csv'); 

% Extract relevant columns
time = data(:, 3);

orientation.r = data(:, 10);
orientation.p = data(:, 11);
orientation.y = data(:, 12);
orientation.w = data(:, 13);

imu_gyro.X = data(:, 15);
imu_gyro.Y = data(:, 16);
imu_gyro.Z = data(:, 17);

imu_accel.X = data(:, 19);
imu_accel.Y = data(:, 20);
imu_accel.Z = data(:, 21);

mag_field.X = data(:, 27);
mag_field.Y = data(:, 28);
mag_field.Z = data(:, 29);

fprintf('Collected %u total data points\n', size(data, 1));

% Call the plotAllanVariance function for accelerometer data
plotAllanVariance(orientation.r, 'Orientation Data Roll');
plotAllanVariance(orientation.p, 'Orientation Data Pitch');
plotAllanVariance(orientation.y, 'Orientation Data Yaw');
plotAllanVariance(orientation.w, 'Angular velocities of R P Y');

% Call the plotAllanVariance function for gyroscope data
plotAllanVariance(imu_gyro.X, 'Gyro Data X');
plotAllanVariance(imu_gyro.Y, 'Gyro Data Y');
plotAllanVariance(imu_gyro.Z, 'Gyro Data Z');

% Call the plotAllanVariance function for accelerometer data
plotAllanVariance(imu_accel.X, 'Accelerometer Data X');
plotAllanVariance(imu_accel.Y, 'Accelerometer Data Y');
plotAllanVariance(imu_accel.Z, 'Accelerometer Data Z');

% Call the plotAllanVariance function for accelerometer data
plotAllanVariance(mag_field.X, 'Magnetic Field Data X');
plotAllanVariance(mag_field.Y, 'Magnetic Field Data Y');
plotAllanVariance(mag_field.Z, 'Magnetic Field Data Z');

